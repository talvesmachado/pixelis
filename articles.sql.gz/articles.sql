-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Mar 06 Novembre 2012 à 18:10
-- Version du serveur: 5.5.9
-- Version de PHP: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `pixelis`
--

-- --------------------------------------------------------

--
-- Structure de la table `articles`
--

CREATE TABLE `articles` (
  `nid` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(255) NOT NULL,
  `titre` varchar(255) CHARACTER SET utf8 NOT NULL,
  `body` varchar(255) CHARACTER SET utf8 NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`nid`),
  KEY `titre` (`titre`),
  KEY `date` (`date`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `articles`
--

INSERT INTO `articles` VALUES(1, 1, 'qsdfqsdf', 'qsdfm jmlkj mljk', '2012-11-06 16:15:37');
INSERT INTO `articles` VALUES(2, 1, 'qsdfqsdf', 'qsdfm jmlkj mljk', '2012-11-06 16:16:30');
INSERT INTO `articles` VALUES(3, 1, 'qsdfqsdf', 'qsdfm jmlkj mljk', '2012-11-06 16:16:35');
