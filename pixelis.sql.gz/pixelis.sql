-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Mer 07 Novembre 2012 à 17:59
-- Version du serveur: 5.5.9
-- Version de PHP: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `pixelis`
--

-- --------------------------------------------------------

--
-- Structure de la table `articles`
--

CREATE TABLE `articles` (
  `nid` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(255) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `body` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`nid`),
  KEY `titre` (`titre`),
  KEY `date` (`date`),
  KEY `nid` (`nid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `articles`
--

INSERT INTO `articles` VALUES(1, 1, 'titre', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In suscipit, metus a viverra vehicula, quam orci blandit dolor, mollis placerat urna urna vulputate urna. Sed imperdiet, turpis eget fringilla pharetra, dolor libero volutpat orci, sed hendrerit fel', '2012-11-07 12:18:45');
INSERT INTO `articles` VALUES(2, 1, 'titre 2', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In suscipit, metus a viverra vehicula, quam orci blandit dolor, mollis placerat urna urna vulputate urna. Sed imperdiet, turpis eget fringilla pharetra, dolor libero volutpat orci, sed hendrerit fel', '2012-11-07 12:20:34');
INSERT INTO `articles` VALUES(3, 1, 'titre 3', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In suscipit, metus a viverra vehicula, quam orci blandit dolor, mollis placerat urna urna vulputate urna. Sed imperdiet, turpis eget fringilla pharetra, dolor libero volutpat orci, sed hendrerit fel', '2012-11-07 12:21:23');
INSERT INTO `articles` VALUES(4, 1, 'titre 3', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In suscipit, metus a viverra vehicula, quam orci blandit dolor, mollis placerat urna urna vulputate urna. Sed imperdiet, turpis eget fringilla pharetra, dolor libero volutpat orci, sed hendrerit fel', '2012-11-07 12:22:50');

-- --------------------------------------------------------

--
-- Structure de la table `files`
--

CREATE TABLE `files` (
  `fid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  `filename` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `uri` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `filemime` varchar(255) NOT NULL DEFAULT '',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0',
  `width` int(10) NOT NULL DEFAULT '0',
  `height` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fid`),
  UNIQUE KEY `uri` (`uri`),
  KEY `nid` (`nid`),
  KEY `fid` (`fid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Stores information for uploaded files.' AUTO_INCREMENT=3 ;

--
-- Contenu de la table `files`
--

INSERT INTO `files` VALUES(1, 3, 'Nicolas-du-Cray-full.jpg', '/Volumes/Travaux/http/pixelis/uploads/Nicolas-du-Cray-full.jpg', 'image/jpeg', 34, 600, 557);
INSERT INTO `files` VALUES(2, 4, 'Nicolas-du-Cray-cut.jpg', '/Volumes/Travaux/http/pixelis/uploads/Nicolas-du-Cray-cut.jpg', 'image/jpeg', 10, 139, 540);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `mail` varchar(255) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`uid`),
  KEY `name` (`name`),
  KEY `mail` (`mail`),
  KEY `created` (`created`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `users`
--

INSERT INTO `users` VALUES(1, 'admin', '7e8037f65b4f9871283b91103b92dcef', 'talvesmachado@pixelis.fr', '2012-11-05 18:35:34');
INSERT INTO `users` VALUES(2, 'test1', '7e8037f65b4f9871283b91103b92dcef', 'talvesmachado+66@pixelis.fr', '2012-11-05 19:02:42');
INSERT INTO `users` VALUES(3, 'test2', '7e8037f65b4f9871283b91103b92dcef', 'talvesmachado+456@pixelis.fr', '2012-11-05 19:07:33');
INSERT INTO `users` VALUES(4, 'test3', '7e8037f65b4f9871283b91103b92dcef', 'talvesmachado+4536@pixelis.fr', '2012-11-05 19:10:16');
INSERT INTO `users` VALUES(5, 'qsdfqsdf', '7e8037f65b4f9871283b91103b92dcef', 'talvesmachado+42536@pixelis.fr', '2012-11-05 19:11:03');
